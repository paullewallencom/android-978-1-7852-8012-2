package com.gamecodeschool.c5platformgame;

public class InputController {

    InputController(int screenWidth, int screenHeight) {

    }
}

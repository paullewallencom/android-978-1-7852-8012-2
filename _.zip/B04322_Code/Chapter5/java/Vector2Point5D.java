package com.gamecodeschool.c5platformgame;

public class Vector2Point5D {

    float x;
    float y;
    int z;

}


package com.gamecodeschool.c6platformgame;

public class Vector2Point5D {

    float x;
    float y;
    int z;

}


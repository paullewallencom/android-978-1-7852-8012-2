package com.gamecodeschool.c8platformgame;

public class Vector2Point5D {

    float x;
    float y;
    int z;

}


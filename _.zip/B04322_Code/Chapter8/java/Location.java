package com.gamecodeschool.c8platformgame;


public class Location {
    String level;
    float x;
    float y;

    Location(String level, float x, float y){
        this.level = level;
        this.x = x;
        this.y = y;
    }

}

package com.gamecodeschool.c7platformgame;

public class Vector2Point5D {

    float x;
    float y;
    int z;

}

